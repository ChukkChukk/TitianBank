/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package edu.spcollege.TitianBank.domain;

/**
 *
 * @author Chukk
 */
public class UserRepository implements IUserRepository{

    /**
     *
     * @param userName
     * @return
     */
    @Override
    public User findByUserName(String userName) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }   
}
